package com.example.fakeelytra;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class FakeElytraClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fake_elytra.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(
                            "Fake Elytra test: " + (enabled ? "ON" : "OFF")
                                    + " (G to toggle; local/test use only)"
                    ), true);
                }
            }

            // Safety-first prototype: do not spoof movement packets or force flight.
            // It only reports whether the player has the expected iron chestplate.
            if (enabled && client.player != null
                    && client.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.IRON_CHESTPLATE)) {
                // Deliberately no server-facing flight manipulation here.
            }
        });
    }
}
