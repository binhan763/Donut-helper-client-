# Fake Elytra — Fabric 1.21.11 (experimental starter)

This is a **source project**, not a prebuilt JAR. It includes a GitHub Actions workflow so you can build the JAR from an Android phone using GitHub.

## Honest scope
- Fabric client mod target: Minecraft Java 1.21.11, Java 21.
- Press **G** to toggle a small on-screen status message.
- The starter intentionally does **not** spoof Elytra state, manipulate movement packets, or bypass DonutSMP anti-cheat. Client-only changes cannot guarantee server-authorized flight.
- This starter is a safe scaffold, not yet a functional fake-Elytra flight implementation.

## Build on Android with GitHub
1. Create a public or private GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself, if GitHub's browser does not extract it).
3. Open **Actions** → **Build Fake Elytra JAR** → **Run workflow**.
4. When finished, open the run, scroll to **Artifacts**, and download `FakeElytra-JAR`.
5. Extract the artifact ZIP and copy the regular `fake-elytra-1.0.0.jar` (not `*-sources.jar`) into `.minecraft/mods` in the Zalith profile.
6. Ensure that profile has Fabric for Minecraft 1.21.11 and Java 21.

## Important
The declared Fabric/Yarn versions are starter defaults and may need updating if the repositories do not publish them. A successful workflow build is not proof of compatibility with a specific server. Use flight mods only in single-player or servers where they are permitted.
