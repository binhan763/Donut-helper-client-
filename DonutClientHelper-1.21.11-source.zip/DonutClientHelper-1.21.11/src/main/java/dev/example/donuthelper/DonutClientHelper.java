package dev.example.donuthelper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class DonutClientHelper implements ClientModInitializer {
    private static KeyBinding statusKey;
    private static boolean enabled = true;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(
                Identifier.of("donut_client_helper", "main")
        );

        statusKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.donut_client_helper.status",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (statusKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal("Donut Client Helper: " + (enabled ? "ON" : "OFF")),
                            true
                    );
                }
            }
        });
    }
}
