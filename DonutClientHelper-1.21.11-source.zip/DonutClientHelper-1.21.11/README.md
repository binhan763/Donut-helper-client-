# Donut Client Helper — Minecraft 1.21.11 / Fabric

This is a minimal client-side Fabric mod project. Right Shift toggles a small ON/OFF status message. It does **not** currently add inventory sorting or custom inventory controls, and it does not bypass authentication or server anti-cheat.

## Target
- Minecraft Java Edition 1.21.11
- Java 21
- Fabric Loader (project uses 0.19.3)
- Fabric API 0.141.6+1.21.11
- Yarn mappings 1.21.11+build.6

## Build a JAR using GitHub Actions (works from a phone)
1. Extract this ZIP.
2. Create a GitHub repository and upload the extracted files, including the `.github/workflows/build.yml` file.
3. Open the repository's **Actions** tab and choose **Build Fabric mod**. Press **Run workflow** (or push a commit to trigger a build).
4. When the run succeeds, open the run and download the artifact named `DonutClientHelper-1.21.11`.
5. Inside the downloaded artifact, use `donut-client-helper-1.0.1.jar` (not the `-sources.jar`).

The build workflow has been provided but was **not run in this environment**. Treat the resulting JAR as unverified until the GitHub Actions run succeeds and you test it in a disposable Zalith instance.

## Install in Zalith Launcher
1. Ensure the selected instance is Minecraft **1.21.11 with Fabric** and Java 21.
2. Download the built JAR artifact and extract it if GitHub provides a ZIP containing the JAR.
3. Put `donut-client-helper-1.0.1.jar` in that instance's `mods` folder.
4. Install a matching Fabric API JAR for Minecraft 1.21.11 into the same `mods` folder.
5. Launch the instance. Press **Right Shift** on a physical keyboard to toggle the status. If using touchscreen only, bind the key to a control your launcher can send, or change the key binding in Options → Controls.

## Important
This is a starter mod only. It does not grant Java Edition entitlement and does not provide automated inventory actions yet.
